<form action="database.php" method="POST">
	
Hva heter du? <br/>

<input type="text" name="navn"> <br/>

Hvor gammel er du? <br/>	
	
<input type="text" name="alder"> <br/>	<br/>
	
<input type="submit" value="Send inn">	
	
</form>
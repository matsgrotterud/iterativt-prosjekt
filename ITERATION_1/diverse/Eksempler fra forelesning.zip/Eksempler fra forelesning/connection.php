<?php		
	$server = "localhost";
	$username = "root";
	$passwd = "root";
	$db = "PJ2100_2016";
		
	// Opprett forbindelse
	
	$conn = mysqli_connect($server, $username, $passwd, $db);
	
	// Sjekk at vi har fått kontakt
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	echo "Connected successfully <br/>";		
	
	//lag eksplisitt spørring mot databasen
	$query1 = "SELECT * FROM Brukere";
		
	$result=mysqli_query($conn,$query1);
	
	//skriv ut innholdet i databasen (navn på brukerne) på websiden:
	while ($person = mysqli_fetch_array($result)) {
		echo $person['Navn']."<br/>";
	}
		
	echo "Legger inn ny bruker i database:<br/>";
	
	//legg inn ny bruker i databasen
	$query2 = "INSERT INTO Brukere (Navn, Alder) VALUES ('Marit', 29) ";
		
	mysqli_query($conn, $query2);
	
	$result=mysqli_query($conn,$query1);
	
	//vi oppdatert innhold:
	while ($person = mysqli_fetch_array($result)) {
		echo $person['Navn']."<br/>";
	}
	
	//lukk forbindelsen
	mysqli_close($conn);
		
?>

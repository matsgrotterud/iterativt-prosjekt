   <?php
   // our database connection variables: 		
   $server = "localhost";
   $username = "root";
   $passwd = "";
   $db = "PJ2100_2016";
		
	// Create connection
	
	$conn = mysqli_connect($server, $username, $passwd, $db);
	
	
   ?>
   
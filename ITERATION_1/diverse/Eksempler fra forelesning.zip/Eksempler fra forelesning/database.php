Skjemaet ble sendt inn! <br/>

<?php

   //echo "Du heter ".$_POST['navn']." og du er ".(int)$_POST['alder']." år.";
	
   		
   include 'db_conn.php';
	
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	echo "Opprettet forbindelse med databasen! <br/><br/>";		
	
		$nyttNavn = $_POST['navn'];
	$alder = $_POST['alder'];
	
	
	$stmt = $conn->prepare("INSERT INTO Brukere (Navn, Alder) VALUES (?, ?)");
	$stmt->bind_param("si", $nyttNavn, $alder);
	
	$stmt->execute();
	
		
	// lese ut innholdet i oppdatert database:
	echo "Oppdatert liste over brukere: <br/>";
	$query1 = "SELECT * FROM Brukere";
	$result=mysqli_query($conn,$query1);
	
	
	while ($person = mysqli_fetch_array($result)) {
		echo $person['Navn']."<br/>";
	}
	
	mysqli_close($conn);
	
	
?>
